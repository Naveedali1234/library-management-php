<?php
    include('header.php');
    require_once('db.php');
    
//	$search=$_POST['search'];
//    $sql="select * from student where student_name  like '%$search%' limit 1";
//    $result=mysql_query($sql);
//    $row=mysql_num_rows($result);
?>

<!--<table class="table">
<thead class="bg-primary">
	 <th>ID</th>
	<th>Name</th>
	<th>Reg #</th>
    <th>batch #</th>
    <th>Department #</th>  

</thead>-->
//<?php
//	if($row > 0){
//		while($data=mysql_fetch_assoc($result)){
//			
//			
//		//echo "<tr>";
//		
//		echo "<tr><td><h3 align:left>".$data['student_name']."</h3></td></tr>";
//		echo "<tr><td> Registration # :".$data['registration_no']."</td></tr>";
//		echo "<tr><td> Batch # :".$data['batch']."</td></tr>";
//		//echo "<tr><td> Department :".$data['department']."</td></tr>";
//		//echo "</tr>";
//		}
//	}
//	else{
//		echo "No data found";
//	}
//	//echo $search;
//
//
//?>
<!--</table>
    
 </div>
 -->
<!-- second part -->    
   //<?php
//    require_once('db.php');
//    
//	$search=$_POST['book_search'];
//    $sql="select * from book where book_title  like '%$search%' limit 1";
//    $result=mysql_query($sql);
//    $row=mysql_num_rows($result);
//?>


<!--<table class="table">
    <thead class="bg-primary">
	<th>Book Titlee</th>
	<th>Book Author</th>
    <th>ISBN</th>
    <th>Publisher</th>  

</thead>-->
//<?php
//	if($row > 0){
//		while($data=mysql_fetch_assoc($result)){
//			
//			
//		echo "<tr align:right>";
//		echo "<td>".$data['book_title']."</td>";
//		echo "<td> Book Author :".$data['book_author']."</td>";
//		echo "<td> ISBN :".$data['isbn']."</td>";
//		echo "<td> Publisher :".$data['publisher']."</td>";
//		echo "</tr>";
//		}
//	}
//	else{
//		echo "No data found";
//	}
//	//echo $search;
//
//
//    ?>
<!--</table>-->
