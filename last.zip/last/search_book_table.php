<?php
	 require_once('db.php');
	 
	  if(isset($_GET['del'])){
        $del_id=$_GET['del'];
        $del_query="DELETE FROM book WHERE isbn = '$del_id'";
        if(mysql_query($del_query)){
            $msg ="user has been deleted";
        }
        else{
            $error ="user has not been deleted";
        }
    }
?>

<?php
    require_once('db.php');
	$search=$_POST['search'];
    $sql="select * from book where book_title  like '%$search%' limit 1";
    $result=mysql_query($sql);
    $row=mysql_num_rows($result);
?>

<table class="table table-bordered">
<thead class="bg-primary">
	<th>Book title</th>
	<th>Book Author</th>
    <th>Book Copies</th>
    <th>ISBN</th>
    <th><a href="" class="bg-primary">Edit</a></th>

</thead>
<?php
	if($row > 0){
		while($data=mysql_fetch_assoc($result)){
			
			$book_title=$data['book_title'];
			$book_author=$data['book_author'];
			$quantity=$data['quantity'];
			$isbn=$data['isbn'];
		}
		?>	
			
		<tr>
		<td><?php echo $book_title ?></td>
		<td><?php echo $book_author ?></td>
		<td><?php echo $quantity ?></td>
		<td><?php  echo $isbn ?></td>
		<td><a rel="tooltip"  title="Edit" href="edit-book.php?edit=<?php echo $isbn ?>"><input type="button" class="btn btn-primary" value="Edit"></a>
            <a rel="tooltip"  title="Delete" href="list_of_book.php?del=<?php echo $isbn ?>"><input type="button" class="btn btn-warning" value="Delete"></a></td>
		</tr>
		<?php 	
	}
	else{
		echo "No data found";
	}


?>
</table>