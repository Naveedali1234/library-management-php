<?php
	if(!empty($_POST["student_name"]) && !empty($_POST["father_name"]) && !empty($_POST["reg_no"]) && !empty($_POST["batch_no"]) && !empty($_POST["department"]) && !empty($_POST["mobile_no"]) && !empty($_POST["email"]) && !empty($_POST["password"]) && !empty($_POST["image"])) {
		print "Message is Saved!";
	}
?>