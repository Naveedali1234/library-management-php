<?php
$server="localhost";
$username="root";
$password="";
$conncetion=mysql_connect("$server","$username","$password");
mysql_select_db("library_management");

?>