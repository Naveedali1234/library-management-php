
<?php
	 require_once('db.php');
	 
	  if(isset($_GET['del'])){
        $del_id=$_GET['del'];
        $del_query="DELETE FROM book WHERE isbn = '$del_id'";
        if(mysql_query($del_query)){
            $msg ="user has been deleted";
        }
        else{
            $error ="user has not been deleted";
        }
    }
?>


<?php include('header.php'); ?>                    
             <div class="container">
     <div class="row panel panel-primary add_student_well">
              <div class="panel-heading bg-primary"><h3><i class="glyphicon glyphicon-book"></i> List of Books</h3></div>
          	<div class="col-md-12">
            <div class="panel-body">
           <?php
           
				$select_query="select * from book";
				$run=mysql_query($select_query);
				if(mysql_num_rows($run) > 0){
					
		
           ?> 
            <!-- label to show the deleted label start-->
           
           
            <?php 
                        if(isset($error)){
						echo "<small class='label pull-right bg-green'>$error</small>";
                            //echo "<span style='color:red;' class='pull-right'>$error</span>";
                        }
                        else if(isset($msg)){
							echo "<small class='label pull-right bg-green'>$msg</small>";
                             //echo "<span style='color:green;' class='pull-right'>$msg</span>";
                        }
                    ?>
           <!-- label to show the deleted label end-->
            
              <table id="example1" class="table table-bordered table-striped">
                <thead class="bg-primary">
                <tr>
                  <th>Book Title</th>
                  <th>Author</th>
                  <th>ISBN</th>
                  <th>Publisher</th>
                  <th>Book Copies</th>
                  <th>Remaining Books</th>
                   <th>Action</th>
                </tr>
                </thead>
                <tbody>
                
                <?php 
                    while($row=mysql_fetch_array($run))
                            {
                                $book_title=$row['book_title'];
                                $book_author=$row['book_author'];
                                $isbn=$row['isbn'];
                                $publisher=$row['publisher'];
                                $quantity=$row['quantity'];
                                $remaining_books=$row["remaining_quantity"];
                                $_SESSION['remain']=$remaining_books;
                                

                               
                   ?>
                
                    <tr>
                  <td><?php echo $book_title ?></td>
                  <td><?php echo $book_author ?></td>
                  <td><?php echo $isbn ?></td>
                  <td><?php echo $publisher ?></td>
                  <td><?php echo $quantity?></td>
                  <td><?php echo $remaining_books?></td>
                
                  <td><a rel="tooltip"  title="Edit" href="edit-book.php?edit=<?php echo $isbn ?>"><input type="button" class="btn btn-primary" value="Edit"></a>
                  <a rel="tooltip"  title="Delete" href="list_of_book.php?del=<?php echo $isbn ?>"><input type="button" class="btn btn-warning" value="Delete"></a></td>
                </tr>
               <?php  } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Book Title</th>
                  <th>Author</th>
                  <th>ISBN</th>
                  <th>Publisher</th>
                  <th>Quantity</th>
                  <th>Remaining Books</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
              
              <?php 
                            
                    } // if statement wala
                    else{
                        echo "<center><h2>no user availble </h2></center>";
                    	}	
                  ?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
                
                </div>
             </div>  <!--row --> 
             
     



