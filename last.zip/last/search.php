<?php
	 require_once('db.php');
	 
	  if(isset($_GET['del'])){
        $del_id=$_GET['del'];
        $del_query="DELETE FROM student WHERE registration_no = '$del_id'";
        if(mysql_query($del_query)){
            $msg ="user has been deleted";
        }
        else{
            $error ="user has not been deleted";
        }
    }
?>



<?php
    require_once('db.php');
	$search=$_POST['search'];
    $sql="select * from student where student_name  like '%$search%' limit 1";
    $result=mysql_query($sql);
    $row=mysql_num_rows($result);
?>


<table class="table table-bordered">
<thead class="bg-primary">
	<th>Name</th>
	<th>Reg #</th>
    <th>batch #</th>
    <th>Department #</th>
    <th><a href="" class="bg-primary">Edit</a></th>

</thead>
<?php
	if($row > 0){
		while($data=mysql_fetch_array($result)){
			$student_name=$data['student_name'];
            $father_name=$data['father_name'];
            $reg_no=$data['registration_no'];
            $batch_no=$data['batch'];
            $department=$data['department'];
        }
          ?>  
			
		<tr>
		<td><?php echo $student_name ?></td>
		<td><?php echo $reg_no ?></td>
		<td><?php echo $batch_no ?></td>
		<td><?php  echo $department ?></td>
		<td><a rel='tooltip'  title='Edit' href='edit-student.php?edit=<?php echo $reg_no ?>'><input type='button' class='btn btn-primary' value='Edit'></a>
            <a rel='tooltip'  title='Delete' href='search_student.php?del=<?php echo $reg_no ?>'><input type='button' class='btn btn-warning' value='Delete'></a></td>
		</tr>
	<?php 	
	}
	else{
		echo "No data found";
	}
       
	//echo $search;


?>
</table>