<?php
    include('header.php');
require_once('db.php');

  if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $cnic=$_POST['cnic'];
    $department=$_POST['department'];
    

    mysql_query("INSERT INTO faculty (name,cnic,department) VALUES('$name','$cnic','$department')");
    
    header('location:list_of_faculty.php');
  }

?>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.6/angular.min.js"></script>
 <div class="container" ng-app="">
     <div class="row panel panel-primary add_student_well">
              <div class="panel-heading bg-primary"><h3><i class="glyphicon glyphicon-plus"></i> Add Faculty</h3></div>
              
              
              
          	<div class="col-md-6">
               
                    <div class="panel-body" >
            	<form method="post" id="frmDemo" action="add_faculty.php" enctype="multipart/form-data">
                <div class="form-group">
                <label>faculty Name:</label>

                <div class="input-group  input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                    <input type="text" name="name" id="name" class="form-control" ng-model="name">
                
                </div>
                
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
               
                 <div class="form-group">
                <label>CNIC #:</label>

                <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                    <input type="text" name="cnic" id="cnic" class="form-control" ng-model="cnic">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
               
                 <div class="form-group">
                <label>Department:</label>

                <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                  <input type="text" name="department" id="department" class="form-control" ng-model="department">
                </div>
                <!-- /.input group -->
              </div>
                
              <!-- /.form group -->
              <input type="submit" value="Add Faculty" name="submit" id="submit" class="btn btn-primary">
              </form>
              
              
                       
         </div>
                    
                </div><br><br>
                <div class="row  col-md-6"style="margin-top:-10px;">
                    <div class="add_student_well" style="padding:10px;"><strong>&nbsp;Faculty Name: </strong><span></span><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="name"></p></div>
                    <div class="add_student_well" style="padding:10px;"><strong>&nbsp;CNIC:</strong><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="cnic"></p></div>
                    <div class="add_student_well" style="padding:10px;"><strong>&nbsp;Department:</strong><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="department"></p></div>
                    
                    <br><br>
                </div>
     </div>
 </div>


