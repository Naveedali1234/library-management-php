<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<?php session_start(); 
include('header.php');
require __DIR__.'/includes/BarcodeBase.php';
//require __DIR__.'/includes/QRCode.php';
//require __DIR__.'/includes/DataMatrix.php';
//require __DIR__.'/includes/PDF417.php';
//require __DIR__.'/includes/Code39.php';
require __DIR__.'/includes/Code128.php';
$bcode = array();
//$bcode['qr']	= array('name' => 'QR Code', 'obj' => new emberlabs\Barcode\QRCode());
//$bcode['dm']	= array('name' => 'DataMatrix', 'obj' => new emberlabs\Barcode\DataMatrix());
//$bcode['p417'] 	= array('name' => 'PDF417', 'obj' => new emberlabs\Barcode\PDF417());
//$bcode['c39']	= array('name' => 'Code39', 'obj' => new emberlabs\Barcode\Code39());
$bcode['c128']	= array('name' => 'Code128', 'obj' => new emberlabs\Barcode\Code128());

  

  
function bcode_img64($b64str)
{

echo "<input type='button' value='print' class='btn btn-primary' onclick='window.print()'";
?>  
    

  <table class="table table-bordered table-hover">
    
    <tbody>
      <tr>
      	

        <td><p style="margin-left:8%";> ISBN</p><?php echo "<img src='data:img/png;base64,$b64str' />" ?> <p style="margin-left:8%";><?php echo $session_barcode=$_SESSION['barcode'];  ?></p></td>
        
      </tr>
      
    </tbody>
  </table>
</div>


<?php } ?>





<?php 
	foreach($bcode as $k => $value)
	{
		try
		{  
			require_once('db.php');
			$query="select barcode_id from book";
			$run=mysql_query($query);
			while($row=mysql_fetch_array($run)){
			$barcode=$row['barcode_id'];
			//echo $barcode ."<br>";
			$_SESSION['barcode']=$barcode;
			$session_barcode=$_SESSION['barcode'];

			$bcode[$k]['obj']->setData($barcode);
			$bcode[$k]['obj']->setDimensions(300, 150);
			$bcode[$k]['obj']->draw();
			$b64 = $bcode[$k]['obj']->base64();
			//bcode_success($bcode[$k]['name']);
			bcode_img64($b64);

			

		} }
		catch (Exception $e)
		{
			//bcode_error($e->getMessage());
		}
	}
?>



