<?php
 require_once('db.php');
    include('header.php');
    if(isset($_POST["submit"]))
    {
        $brcode_id=$_POST["barcode_id"];
        $student_registration_no=$_POST["student_registration_no"];
        //$issue_date=$_POST["issue_date"];
        $accession_no=$_POST["acession_no"];
        $row=mysql_query("select accession_no from borrowing_info where barcode_id='$brcode_id'");
        $access_no=mysql_fetch_assoc($row);
        if($access_no["accession_no"]==$_POST['acession_no'] && !($access_no['accession_no']==null) && !($_POST['acession_no']==null))
        {
            mysql_query("delete from borrowing_info where accession_no='$accession_no'");
            $select_remaining_quantity=mysql_query("select remaining_quantity from book where barcode_id='$brcode_id'");
            $remaining_quantity=mysql_fetch_assoc($select_remaining_quantity);
            $updated_remaining_quantity=$remaining_quantity['remaining_quantity']+1;
            echo $updated_remaining_quantity;
            
           mysql_query("update book set remaining_quantity='$updated_remaining_quantity' where barcode_id='$brcode_id'");
        }
        else
        {
            echo 'There are no accession no like this';
        }
    }
?>
<div class="container">
             <div class="row panel panel-primary add_student_well">
                  <div class="panel-heading bg-primary"><h3><i class="glyphicon glyphicon-share-alt"></i> Return Book</h3></div>
          	
                    <div class="panel-body">
                       <div class="col-lg-12">

                           <form action="return_book.php" method="post">
                               
<!--                                text field of issuing date of a book
                               <div class="form-group">
                                    <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                                    <div class="input-group input-group-lg col-lg-6">
                                      <div class="input-group-addon">Issue Date:</div>
                                      <input type="date" class="form-control" id="exampleInputAmount" name="issue_date" placeholder="Issuing date">
                         
                                    </div>
                               </div>-->
                               
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                                    <div class="input-group input-group-lg col-lg-6">
                                      <div class="input-group-addon">Student Registration no:</div>
                                      <input type="text" class="form-control search" id="exampleInputAmount" name="student_registration_no" placeholder="student registration no">
                         
                                    </div>
                               </div>
                                
                                
                                 <div class="form-group">
                                    <div class="input-group input-group-lg col-lg-12">
                                      <div class="input-group-addon">Barcode ID:</div>
                                      <input type="text" class="form-control" id="barcode_id_textBox"   name="barcode_id" placeholder="Barcode ID">
                                      <span class="input-group-btn" style="width:0px;"></span>
                                      <input type="text" class="form-control " id="book_title_textBox"   name="book_title" placeholder="Book title">

                                    </div>
                               </div>
                                
                                
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                                    <div class="input-group input-group-lg col-lg-6">
                                      <div class="input-group-addon">Acession no:</div>
                                      <input type="text" class="form-control " id="exampleInputAmount" name="acession_no" placeholder="accession no">
                         
                                    </div>
                                </div>
                                    <div>
                                    
                                        <input type="submit" value="Return Book" name="submit" class="btn btn-lg btn-primary">
                                    </div>
                                        </form>
                


                        </div><!-- /.col-lg-6 -->

<!--                        <div class="col-lg-6">
                           <form action="sub_issue_book_table.php" method="post">
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                                    <div class="input-group input-group-lg">
                                      <div class="input-group-addon">Search</div>
                                      <input type="text" class="form-control search2" id="exampleInputAmount" name="search" placeholder="Search Book to issue">
                         
                                    </div>
                               </div>
                          
                          </form>
                
                       </div> /.col-lg-6 
              -->
	            </div><!-- /.row -->
	    </div>
	    
	</div>

