<?php session_start();
    require_once('db.php');
    include('header.php');
    if(isset($_POST["submit"]))
    {
		$barcodeid=$_SESSION['barcodeid'];
        //$brcode_id=$_POST["barcode_id"];
        $student_registration_no=$_POST["student_registration_no"];
        //$issue_date=$_POST["issue_date"];
        $accession_no=$_POST["acession_no"];
        $row=mysql_query("select remaining_quantity from book where barcode_id='$barcodeid'");
		
        $remaining_quantity=mysql_fetch_assoc($row);
        $row2=mysql_query("select accession_no from book_copy where accession_no='$accession_no'");
        $access_no_of_book_copy=mysql_fetch_assoc($row2);
        if($remaining_quantity["remaining_quantity"]>=1 && $access_no_of_book_copy["accession_no"]==$_POST['acession_no'])
        {
            mysql_query("insert into borrowing_info(barcode_id,registration_no,accession_no)"
                    . "values ('$barcodeid','$student_registration_no','$accession_no')");
            $select_remaining_quantity=mysql_query("select remaining_quantity from book where barcode_id='$barcodeid'");
            $remaining_quantity=mysql_fetch_assoc($select_remaining_quantity);
            $updated_remaining_quantity=$remaining_quantity['remaining_quantity']-1;
            echo  $updated_remaining_quantity;
            
           mysql_query("update book set remaining_quantity='$updated_remaining_quantity' where barcode_id='$barcodeid'");
        }
        else
        {
            echo 'There are no books left in the library to issue';
        }
    }
?>

  <script>

$('document').ready(function() {
    
var searchKey;
var searchTimeout;//Timer to wait a little before fetching the data
$('#barcodeid_textBox').keyup(function() {
      searchKey = $(this).val();

    clearTimeout(searchTimeout);

    searchTimeout = setTimeout(function() {
        barcodeTextboxFill(searchKey);    
    }, 400); //If the key isn't pressed 400 ms, we fetch the data
});
function barcodeTextboxFill(searchKey){
     $.ajax({
        url: 'fetching_book_title_for_barcode.php',
        type: 'POST',
        dataType: 'json',
        data: {value: searchKey},
        success: function(data) {
                $("#book_title_textBox").val(data.book_title1.book_title);
        }
    }); 
        
}
})



   </script>
   
   <!-- code for return book start -->
   
   <?php
 require_once('db.php');
    //include('header.php');
    if(isset($_POST["return_submit"]))
    {
        //$brcode_id=$_POST["barcode_id"];
		$barcodeid=$_SESSION['barcodeid'];
        $student_registration_no=$_POST["student_registration_no"];
        //$issue_date=$_POST["issue_date"];
        $accession_no=$_POST["acession_no"];
        $row=mysql_query("select accession_no from borrowing_info where barcode_id='$barcodeid'");
        $access_no=mysql_fetch_assoc($row);
        if($access_no["accession_no"]==$_POST['acession_no'] && !($access_no['accession_no']==null) && !($_POST['acession_no']==null))
        {
            mysql_query("delete from borrowing_info where accession_no='$accession_no'");
            $select_remaining_quantity=mysql_query("select remaining_quantity from book where barcode_id='$barcodeid'");
            $remaining_quantity=mysql_fetch_assoc($select_remaining_quantity);
            $updated_remaining_quantity=$remaining_quantity['remaining_quantity']+1;
            echo $updated_remaining_quantity;
            
           mysql_query("update book set remaining_quantity='$updated_remaining_quantity' where barcode_id='$barcodeid'");
        }
        else
        {
            echo 'There are no accession no like this';
        }
    }
?>

	<!-- end of return -->
    
    
<html>
<head>
	<title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- code for scanner -->
    <script type="text/javascript">

$(document).scannerDetection({
    
  //https://github.com/kabachello/jQuery-Scanner-Detection

    timeBeforeScanTest: 200, // wait for the next character for upto 200ms
    avgTimeByChar: 40, // it's not a barcode if a character takes longer than 100ms
  endChar: [13],
  //preventDefault: true, //this would prevent text appearing in the current input field as typed 
        onComplete: function(barcode, qty){
   
    alert(barcode);
    } // main callback function 
});



</script>
    
</head>
<body>
		<div class="container">
        <div class="row panel panel-primary">
        <div class="panel-heading bg-primary" style="text-align:center"><h3><i class="glyphicon glyphicon-barcode"></i> Book Barcode</h3></div>
          	<div class="col-md-12">

	<form method="POST">

		<!-- <input type="text" name="barcode" autofocus> -->
		 <div class="form-group">
                <!-- <label style="text-align:center;"></label> -->
                

                <div class="input-group row col-md-6 input-group-lg" style="margin-left:20%; margin-top:10px;">
                  <div class="input-group-addon">
                    <i class="fa fa-barcode"></i>
                  </div>
                  <input type="text" name="barcode" class="form-control" autofocus placeholder="Scan book barcode">
                </div>
                <!-- /.input group -->
              </div>


	</form>
	<table id="example1" class="table table-bordered table-striped">
                <thead class="bg-primary">
                <tr>
                  <th>Book Title</th>
                  <th>Author</th>
                  <th>ISBN</th>
                  <th>Publisher</th>
                  <th>Total Copies</th>
                  <th>Remaining Copies</th>
                  <th>Issue Book</th>
                  <th>Return Book</th>
                  
                </tr>
                </thead>
                <tbody>
                <?php 
				require_once('db.php');
	if (isset($_POST['barcode'])) {
				$barcode = $_POST['barcode'];
				
				$_SESSION['barcodeid']=$barcode;
				
				
				 $select_query="select * from book where barcode_id='$barcode'";
				 $run=mysql_query($select_query);
				 
                $row=mysql_fetch_array($run);
			 
                                $book_title=$row['book_title']; 
                                $book_author=$row['book_author'];
                                $isbn=$row['isbn'];
                                $publisher=$row['publisher'];
                             	  $quantity=$row['quantity'];
								 $remaining_quantity=$row['remaining_quantity'];
			   
				 
    ?>
     <tr>
                  <td><?php echo $book_title ?></td>
                  <td><?php echo $book_author ?></td>
                  <td><?php echo $isbn ?></td>
                  <td><?php echo $publisher ?></td>
                  <td><?php echo $quantity ?></td>
                  <td><?php echo $remaining_quantity ?></td>
                  <td><button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-lg">Issue Book</button></td>
<td><button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target=".return-example-modal-lg">Return Book</button></td>                
                
               
                </tr>
               <?php } ?>
                </tbody>
                </table>
                </div>
                </div>
                </div>
                
               
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- codoe for issue model start -->

<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2 class="modal-title" style="text-align:center">Issue Book</h2>
      </div>
      
      
      <div class="modal-body">
          <form method="post">
            <!--text field of issuing date of a book
               <div class="form-group">
                  <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                     <div class="input-group input-group-lg">
                       <div class="input-group-addon">Issue Date:</div>
                 <input type="date" class="form-control" id="exampleInputAmount" name="issue_date" placeholder="Issuing date">
                         
                          </div>
                  </div> -->
                               
                 <div class="form-group">
                    <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                       <div class="input-group input-group-lg">
                         <div class="input-group-addon">Student Registration no:</div>
                   <input type="text" class="form-control search" id="exampleInputAmount" name="student_registration_no" placeholder="student registration no">
                         
                        </div>
                  </div>
                  
                   
                 <!-- <div class="form-group">
                     <div class="input-group input-group-lg col-lg-12">
                       <div class="input-group-addon">Barcode ID:</div>
                 <input type="text" class="form-control" id="barcode_id_textBox"   name="barcode_id" >
                         <span class="input-group-btn" style="width:0px;"></span>
                <input type="text" class="form-control " id="book_title_textBox"   name="book_title" placeholder="Book title">

                   </div>
                </div>  -->
                                
                  <div class="form-group">
                     <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                        <div class="input-group input-group-lg">
                           <div class="input-group-addon">Acession no:</div>
               <input type="text" class="form-control " id="exampleInputAmount" name="acession_no" placeholder="accession no">
                         
                          </div>
                      </div>
                      
                       <div>                                 
                      <input type="submit" value="issue Book" name="submit" class="btn btn-lg btn-danger">
                         </div>
                                       
           </form>
                

      </div>
      
      
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div><!-- /.modal-content -->
  </div>
</div>
<!-- codoe for issue model end -->


<!-- codoe for return model start -->

<div class="modal fade return-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2 class="modal-title" style="text-align:center">Return Book</h2>
      </div>
      
      
      <div class="modal-body">
           <form method="post">
                               
              <div class="form-group">
                  <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                    <div class="input-group input-group-lg">
                      <div class="input-group-addon">Student Registration no:</div>
                   <input type="text" class="form-control search" id="exampleInputAmount" name="student_registration_no" placeholder="student registration no">
                         
                      </div>
                  </div>
                                
                                
             <!--   <div class="form-group">
                   <div class="input-group input-group-lg col-lg-12">
                     <div class="input-group-addon">Barcode ID:</div>
                 <input type="text" class="form-control" id="barcode_id_textBox"   name="barcode_id" placeholder="Barcode ID">
                     <span class="input-group-btn" style="width:0px;"></span>
                 <input type="text" class="form-control " id="book_title_textBox"   name="book_title" placeholder="Book title">

                    </div>
             	 </div> -->
                                
                                
                 <div class="form-group">
          		   <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                     <div class="input-group input-group-lg ">
                       <div class="input-group-addon">Acession number:</div>
               <input type="text" class="form-control " id="exampleInputAmount" name="acession_no" placeholder="accession no">
                         
                     </div>
                   </div>
                		<div>
                                    
                   <input type="submit" value="Return Book" name="return_submit" class="btn btn-lg btn-primary">
                     </div>
        </form>
                

      </div>
      
      
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div><!-- /.modal-content -->
  </div>
</div>
<!-- codoe for return model end -->