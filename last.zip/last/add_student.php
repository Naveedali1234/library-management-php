<?php
    include('header.php');
require_once('db.php');
        
	if(filter_input(INPUT_POST, 'submit', FILTER_SANITIZE_STRING)){
                $query='select registration_no from student where registration_no="'.$_POST['reg_no'].'"';
                $check=mysql_query($query);
                if(mysql_num_rows($check)!=0)
                {?>
                    <div class="alert alert-warning alert-dismissable">'
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Warning!</strong> This Student already exist.
                     </div>
               <?php }
                else{
                       // $errors= array();
                         // $file_name = $_FILES['image']['name'];
                         // $file_size =$_FILES['image']['size'];
                          //$file_tmp =$_FILES['image']['tmp_name'];
                          //$file_type=$_FILES['image']['type'];
                          //$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      //                    $expensions= array("jpeg","jpg","png");
      
      //if(in_array($file_ext,$expensions)=== false){
        // $errors[]="extension not allowed, please choose a JPEG or PNG file.";
     // }
      
     // if($file_size > 2097152){
     //    $errors[]='File size must be excately 2 MB';
      //}
      
      if(empty($errors)==true){
                        $target_path = "img/".$file_name;
                        move_uploaded_file($file_tmp,$target_path);
                        $student_name= filter_input(INPUT_POST, 'student_name', FILTER_SANITIZE_STRING);
                        $father_name=filter_input(INPUT_POST, 'father_name', FILTER_SANITIZE_STRING);
                        $reg_no=filter_input(INPUT_POST, 'reg_no', FILTER_SANITIZE_STRING);
                        $batch_no=filter_input(INPUT_POST, 'batch_no', FILTER_SANITIZE_STRING);
                        $department=filter_input(INPUT_POST, 'department', FILTER_SANITIZE_STRING);
                        $password=filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
                        $mobile_no=filter_input(INPUT_POST, 'mobile_no', FILTER_SANITIZE_NUMBER_INT);
                        $email=filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
		//$status=$_POST['status'];
		
		mysql_query("INSERT INTO student (registration_no,student_name,father_name,batch,department,password,student_image) VALUES('$reg_no','$student_name','$father_name','$batch_no','$department','$password','".$_FILES['image']['name']."')");
		
		header('location:list_of_student.php');
      }else{
         print_r($errors);
      }
                       
		
	}
        }

?>

<style>

#error_message{
    background: #F3A6A6;
}
#success_message{
    background: #CCF5CC;
}
.ajax_response {
    padding: 20px 50px;
    border: 0;
    display: inline-block;
    margin-top: 20px;
    cursor: pointer;
	display:none;
	color:#555;
	width:30%;
	height:15%;
}

</style>

				<div id="error_message" class="ajax_response" ></div>
				<div id="success_message" class="ajax_response" ></div>


<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.6/angular.min.js"></script>
 <div class="container" ng-app="">
     <div class="row panel panel-primary add_student_well">
              <div class="panel-heading bg-primary"><h3><i class="glyphicon glyphicon-plus"></i> Add Student</h3></div>
              
              
              
          	<div class="col-md-6">
               
                    <div class="panel-body" >
            	<form method="post" id="frmDemo" action="add_student.php" enctype="multipart/form-data">
                <div class="form-group">
                <label>Student Name:</label>

                <div class="input-group  input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                    <input type="text" name="student_name" id="student_name" class="form-control" ng-model="name">
                
                </div>
                
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
               
                 <div class="form-group">
                <label>Father Name:</label>

                <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                    <input type="text" name="father_name" id="father_name" class="form-control" ng-model="father_name">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
               
                 <div class="form-group">
                <label>Registration Number:</label>

                <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                  <input type="text" name="reg_no" id="reg_no" class="form-control" ng-model="registration_no">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
                <div class="form-group">
                <label>Batch Number:</label>

                <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                  <input type="text" name="batch_no" id="batch_no" class="form-control" ng-model="batch_no">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
                <div class="form-group">
                <label>Department:</label>

                <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-list"></i>
                  </div>
                  <select name="department" id="department" class="form-control selectpicker" ng-model="department">
                      <option value="">Select Department</option>
                      <option>Department of Computer Software</option>
                      <option>Department of Telecommunication</option>
                      <option >Department of Electrical Engineering Power</option>
                      <option >Department of Electrical Engineering Communication</option>
                  </select>
                </div>
                <!-- /.input group -->
              </div>
              
              <!-- /.form group -->
              
              <div class="form-group">
                <label>Mobile Number:</label>

                <div class="input-group input-group-lg ">
                  <div class="input-group-addon">
                    <i class="fa fa-mobile"></i>
                  </div>
                  <input type="text" name="mobile_no" id="mobile_no" class="form-control" ng-model="mobile_no">
                </div>
                <!-- /.input group -->
              </div>
              
              <div class="form-group">
                <label>Email:</label>

                <div class="input-group input-group-lg ">
                  <div class="input-group-addon">
                    <i class="fa fa-address-book"></i>
                  </div>
                  <input type="text" name="email" id="email" class="form-control" ng-model="email">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
<!--              <div class="form-group">
                  <label for="status">Status</label>
                  <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-laptop"></i>
                  </div>
                  <select class="form-control" name="status" id="sel1">
                  	
                    <option>Active</option>
                    <option>Inactive</option>
                    
                  </select>
                  </div>
      			 </div>-->
              
              <!-- /.form group -->
              
                <div class="form-group">
                <label>Password:</label>

                <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-lock"></i>
                  </div>
                  <input type="password" name="password" id="password" class="form-control">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
               <div class="form-group">
                <label>Upload Image:</label>

                <div class="input-group input-group-lg">
                  <div class="input-group-addon">
                    <i class="fa fa-image"></i>
                  </div>
                  <input type="file" name="image" id="image" class="form-control">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
              <input type="submit" value="Add student" name="submit" id="submit" class="btn btn-primary">
              </form>
              
              
                       
         </div>
                    
                </div><br><br>
                <div class="row  col-md-6"style="margin-top:-10px;">
                    <div class="add_student_well" style="padding:10px;"><strong>&nbsp;Student Name: </strong><span></span><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="name"></p></div>
                    <div class="add_student_well" style="padding:10px;"><strong>&nbsp;Fther Name:</strong><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="father_name"></p></div>
                    <div class="add_student_well" style="padding:10px;"><strong>&nbsp;Registration No:</strong><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="registration_no"></p></div>
                    <div class="add_student_well" style="padding:10px;"> <strong>&nbsp;Batch no:</strong><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="batch_no"></p></div>
                    <div class="add_student_well" style="padding:10px;"><strong>&nbsp;Department:</strong><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="department"></p></div>
                    <div class="add_student_well" style="padding:10px;"><strong>&nbsp;Mobile No:</strong><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="mobile_no"></p></div>
                    <div class="add_student_well" style="padding:10px;"> <strong>&nbsp;Email:</strong><p style="padding-left: 5px; color:blue; font-family:bold; font-size:30px" ng-bind="email"></p></div>
                    <br><br>
                </div>
     </div>
 </div>


 <!--  script for fade out -->

<script src="http://code.jquery.com/jquery-1.10.2.js"></script>     
<script>
$("#frmDemo").submit(function(e) {
  e.preventDefault();
  var student_name = $("#student_name").val();
  var father_name = $("#father_name").val();
  var reg_no = $("#reg_no").val();
  var batch = $("#batch_no").val();
  var department = $("#department").val();
  var mobile = $("#mobile_no").val();
  var email = $("#email").val();
  var password = $("#password").val();
  var image = $("#image").val();
  
  
  if(student_name == "" || father_name == "" || reg_no == ""|| batch == ""|| department == ""|| mobile == ""|| email == ""|| password == ""|| image == "") {
    $("#error_message").show().html("<h2>All Fields are Required</h2>");
  } else {
    $("#error_message").html("").hide();
    $.ajax({
      type: "POST",
      url: "post-form.php",
      data: "student_name="+student_name+"&father_name="+father_name+"&reg_no"+reg_no+"&batch"+batch+"&department"+department+"&mobile"+mobile+"&email"+email+"&password"+password+"&image"+image,
      success: function(data){
        $('#success_message').fadeIn().html("<h3>data submitted successfully</h3>");
        setTimeout(function() {
          $('#success_message').fadeOut("slow");
        }, 2000 );

      }
    });
  }
})
</script> 











